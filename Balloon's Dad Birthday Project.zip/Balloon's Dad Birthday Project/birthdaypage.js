// ================= START BUTTON =================
document.querySelector('.start-btn').onclick = () => {
    document.querySelector('.start-screen').style.display = 'none';
    document.querySelector('.birthday-section').style.display = 'block';
};

// ================= NEXT BUTTON =================
document.querySelector('.next').onclick = () => {
    document.querySelector('.birthday-section').style.display = 'none';
    document.querySelector('.cake').style.display = 'flex';
};

// ================= FIREWORKS =================
const fireworks = document.querySelector('.fireworks');

function createFirework() {
    const fw = document.createElement('div');
    fw.className = 'firework';
    fw.style.left = Math.random() * 100 + '%';
    fw.style.top = Math.random() * 60 + '%';
    fireworks.appendChild(fw);
    setTimeout(() => fw.remove(), 1000);
}

setInterval(createFirework, 400);

// ================= CANDLES =================
const candles = document.querySelectorAll('.candle');
const wishBtn = document.querySelector('.wish-btn');
const wishOverlay = document.querySelector('.wish-overlay');
const closeWish = document.querySelector('.close-wish');

candles.forEach(candle => {
    candle.addEventListener('click', () => {

        const flame = candle.querySelector('.flame');
        if (flame) flame.remove();

        // เช็คว่าไม่มีไฟเหลือแล้ว
        if (document.querySelectorAll('.flame').length === 0) {
            setTimeout(() => {
                wishBtn.style.display = 'inline-block';
            }, 500);
        }
    });
});

// ================= SEE BIRTHDAY WISHES =================
wishBtn.addEventListener('click', () => {
    wishOverlay.style.display = 'flex';
});

// ================= CLOSE POPUP =================
closeWish.addEventListener('click', () => {
    wishOverlay.style.display = 'none';
});
document.querySelector('.reset-btn').addEventListener('click', () => {

    // ซ่อนทุก section
    document.querySelector('.cake').style.display = 'none';
    document.querySelector('.birthday-section').style.display = 'none';

    // กลับไปหน้าแรก
    document.querySelector('.start-screen').style.display = 'flex';

    // รีเซ็ตเทียนทั้งหมด
    document.querySelectorAll('.candle').forEach(candle => {
        if (!candle.querySelector('.flame')) {
            const flame = document.createElement('div');
            flame.className = 'flame';
            candle.appendChild(flame);
        }
    });

    // ซ่อนปุ่ม reset
    document.querySelector('.reset-btn').style.display = 'none';
});